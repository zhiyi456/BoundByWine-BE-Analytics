from app import client
from flask import jsonify
from models.scraped_data import *


def scraped_data_get_all():
    scraped_data_list = ScrapedData.query.all()
    
    if scraped_data_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scraped_data": [scraped_data.json() for scraped_data in scraped_data_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no Historical Demand."
        }
    ), 404


def selected_scraped_product_price_get_all(product_name):
    scraped_data_list = ScrapedData.query.filter_by(Product_Name = product_name).all()
    if scraped_data_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scraped_data": [scraped_data.json() for scraped_data in scraped_data_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No historical demand history for product named ' + str(product_name) 
        }
    ), 404

def get_new_listing():
    
    return