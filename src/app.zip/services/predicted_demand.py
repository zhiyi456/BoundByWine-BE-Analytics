from app import client
from flask import jsonify
from models.predicted_demand import *

# import the necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pmdarima

# for Model Training
from pmdarima import auto_arima
from statsmodels.tsa.arima.model import ARIMA
import itertools
import statsmodels.api as sm
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_percentage_error, mean_squared_error
from statsmodels.tsa.holtwinters import ExponentialSmoothing # Holt-Winters 
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
from statsmodels.tsa.seasonal import seasonal_decompose
import statsmodels.tsa.api as smt 

def run_specific_product_predicted_demand_model(Product_Name):
    df = pd.read_csv('datasets/cleaned_orders.csv')
    grouped = df[['order_date', 'item_id', 'item_quantity']]
    groupedbyitem = grouped.groupby('item_id', group_keys=True).apply(lambda x:x)
    sample = groupedbyitem[groupedbyitem['item_id']==Product_Name]
    sample = sample.groupby('order_date')['item_quantity'].sum().reset_index()
    sample['order_date'] = pd.to_datetime(sample['order_date'])
    sample = sample.set_index('order_date')

    monthly_sales = pd.DataFrame()
    monthly_sales['sales'] = sample['item_quantity'].resample('MS').mean()

    # Training time
    x = monthly_sales.index
    y = monthly_sales.sales
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.25, random_state = 69, shuffle=False)

    # ARIMA
    auto_arima(y_train, test='adf',seasonal=True, trace=True, error_action='ignore', suppress_warnings=True)
    auto_arima(y,test='adf',
               seasonal=True,
               trace=True,
               error_action='ignore',
               suppress_warnings=True,
               stepwise=True)
    model_arima = ARIMA(y_train, order=(1,1,1)).fit()
    # model_arima.summary()
    pred_arima = model_arima.predict(start=len(y_train), end=(len(y)-1),dynamic=True)

    # SARIMAX
    model_sarimax = sm.tsa.statespace.SARIMAX(y_train,order=(1, 1, 1),seasonal_order=(1,1,1,12))
    results_sarimax = model_sarimax.fit()
    pred_sarimax = results_sarimax.predict(start= len(y_train), end= (len(y)-1),dynamic=True)

    # Ensemble Learning
    rmse_results = []
    mape_results = []

    for weight in np.arange(0.1, 1.0, 0.1):
        # Calculate the weighted average of the two predictions
        weighted_average = (weight * np.array(pred_arima)) + ((1 - weight) * np.array(pred_sarimax))
        
        # Calculate MSE and MAPE
        rmse = mean_squared_error(y_test, weighted_average, squared=False)
        mape = mean_absolute_percentage_error(y_test, weighted_average)
        
        # Append results to the lists
        rmse_results.append((weight, rmse))
        mape_results.append((weight, mape))
    
    # Find the weight with the lowest RMSE
    # Can change to MAPE also
    min_rmse_weight = None
    min_rmse = float('inf')

    for weight, rmse in rmse_results:
        if rmse < min_rmse:
            min_rmse = rmse
            min_rmse_weight = weight
    
    # Showtime
    weight_arima = min_rmse_weight

    future_sales_arima = model_arima.predict(start=len(y), end=(len(y)+12))
    future_sales_sarimax = results_sarimax.predict(start= len(y), end=(len(y)+12))

    future_sales_weighted = (weight_arima * future_sales_arima) + ((1 - weight_arima) * future_sales_sarimax)
    # print(future_sales_weighted)

    # Final return
    y_df = pd.DataFrame({'Product_Name': Product_Name, 'Historical_Demand_Date':y.index, 'Historical_Demand_Sales':y.values})
    historical_demand = y_df.to_dict('records')

    future_sales_weighted_df = pd.DataFrame({'Product_Name': Product_Name, 'Predicted_Demand_Target_Date':future_sales_weighted.index, 'Predicted_Demand_Prediction':future_sales_weighted.values})
    predicted_demand = future_sales_weighted_df.to_dict('records')

    return historical_demand, predicted_demand

# get_specific_product_predicted_demand("Rara Neagră de Purcari 2020")

def post_prediction_to_db(predicted_demand):
    product_name = predicted_demand[0]['Product_Name']
    
    # Get existing records with the same product_name
    existing_records = PredictedDemand.query.filter_by(Product_Name=product_name).all()

    if existing_records:
        # Delete existing records
        for record in existing_records:
            db.session.delete(record)
    
    # Insert new records
    try:
        for pdt in predicted_demand:
            to_db = PredictedDemand(**pdt)
            db.session.add(to_db)
        
        db.session.commit()
        return jsonify(
            {
                "code": 201,
                "data": predicted_demand,
                "message": "Predicted demand for this product has been successfully stored into the database."
            }
        ), 201
    except Exception as e:
        db.session.rollback()  # Rollback changes if an error occurs
        return jsonify(
            {
                "code": 500,
                "data": pdt,
                "message": "An error occurred creating a particular predicted demand record.",
                "error": str(e)
            }
        ), 500


# def get_all_predicted_demand():
#     predicted_demand_list = PredictedDemand.query.all()
    
#     if predicted_demand_list:
#         return jsonify(
#             {
#                 "code": 200,
#                 "data": {
#                     "predicted_demand": [predicted_demand.json() for predicted_demand in predicted_demand_list]
#                 }
#             }
#         )
#     return jsonify(
#         {
#             "code": 404,
#             "message": "There are no Predicted Demand."
#         }
#     ), 404


def get_product_predicted_demand(product_name):
    predicted_demand_list = PredictedDemand.query.filter_by(Product_Name = product_name).all()
    if predicted_demand_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "predicted_demand": [predicted_demand.json() for predicted_demand in predicted_demand_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No predicted demand history for product named ' + str(product_name) 
        }
    ), 404
