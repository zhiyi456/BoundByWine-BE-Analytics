from app import app,db
from flask import jsonify
from models.scraped_data import *
from models.scrape_logs import *
from services.scraped_data import *

import pandas as pd
import time
from datetime import datetime
import requests

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
# from bs4 import BeautifulSoup
from webdriver_manager.chrome import ChromeDriverManager
#https://googlechromelabs.github.io/chrome-for-testing/#stable
import chromedriver_binary
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver import ActionChains


def post_to_db(dataframe, new_product): # helper function
    products = dataframe.to_dict('records')
    for pdt in products:
        to_db = ScrapedData(**pdt)
        try:
            db.session.add(to_db)
            db.session.commit()
        except:
            return jsonify(
                {
                    "code": 500,
                    "data": pdt,
                    "message": "An error occured creating a particular scraped product."
                }
            ), 500
    return jsonify(
        {
            "code": 201,
            "data": new_product,
            "message": "All webscraped products have been successfully stored into the database."
        }
    ), 201

def record_scraping(supplier_name, datetime):
    log = ScrapeLogs(Supplier_Name = supplier_name, 
                Scraped_Data_Datetime = datetime)
    try:
        db.session.add(log)
        db.session.commit()
    except:
        return jsonify(
                {
                    "code": 500,
                    "data": log,
                    "message": "An error occured while uploading scrape log."
                }
            ), 500
    return jsonify(
        {
            "code": 201,
            "message": "Scraping log has been successfully updated."
        }
    ), 201

def get_scraped_data():
    #pass in name returns old price
    response = requests.get('http://127.0.0.1:5000/scraped_data')
    if response.status_code == 200:
        # Parse the JSON data from the response
        response_data = response.json()

        # Access all the wines scraped (all details)
        wines = response_data["data"]["scraped_data"]
        return wines
        # Print the product name
        #print(product_name)
    else:
        print("Request failed with status code:", response.status_code)
        return []
    

def get_old_price(product_name, wines):
    dt = '2023-03-20 12:00:00' #datetime variable
    similar_listing = []
    if len(wines) > 0:
        for wine in wines:
            #get similar listings
            if wine['Product_Name'] == product_name:
                similar_listing.append(wine)
                if wine['Scraped_Data_Datetime'] > dt:
                    dt = wine['Scraped_Data_Datetime']
        if len(similar_listing) != 0:
            for listing in similar_listing:
                if listing['Scraped_Data_Datetime'] == dt:
                    #return the price of the latest old batch listing
                    return listing['Scraped_Data_New_Price']
    #return 0, this product is new
    return 0

def check_new_updates(product_name, wines):
    for wine in wines:
        if wine['Product_Name'] == product_name:
            #print(wine['Product_Name'])
            #print(product_name)
            return False
    return True

def scrape_wine_delivery(category, country): # takes in 2 strings: category, country
    driver = webdriver.Chrome()
    wait = WebDriverWait(driver, 10)
    url = "https://wine.delivery/Buy-Wine-Online"
    driver.maximize_window()
    driver.get(url)
    time.sleep(3)

    try:
        button = driver.find_element(By.XPATH, f"//button[text()='Accept']")
        button.click() # accept cookies
    except NoSuchElementException:
        pass

    # clear all filters - all wines to be selected, whole range of prices
    button = driver.find_element(By.XPATH, "//button[text()='Clear All']")
    button.click()

    # now, filter by the given parameters
    if category != '':
        try:
            button = driver.find_element(By.XPATH, f"//label[text()='{category}']")
            button.click()
        except NoSuchElementException:
            pass
    if country != '':
        try:
            button = driver.find_element(By.XPATH, f"//label[text()='{country}']")
            button.click()
        except NoSuchElementException:
            pass
    
    time.sleep(3)

    data = []
    last_height = driver.execute_script("return document.body.scrollHeight")
    count = 50 # pre-set number of scrolls to minimise run time

    for i in range(count): # keep scrolling down
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(3)
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break
        last_height = new_height

    #get all wines
    scraped_wines = get_scraped_data()
    time.sleep(3)
    new_product = []
    try:
        items = driver.find_elements(By.XPATH, "//div[@class='sc-kAyceB eryWgk']")
        # format of each card:
        # # vintage, type (e.g. red wine), region/country, price, discounted price, stock info
        # discounted price & stock info are optional fields
        df = pd.DataFrame(columns=['Product_Name', 'Scraped_Data_New_Price', 'Scraped_Data_Old_Price'])

        for item in items:
            info = item.text
            info = info.split('\n')
            final = [info[0]] # get vintage name
            old_price = get_old_price(info[0], scraped_wines)
            new = check_new_updates(info[0],scraped_wines)
            if ("S$" in info[-1]) == True: # check if there is NO stock info
                new_price = float(info[-1].replace('S$',''))
                final.append(new_price) # no stock info, means last value is a price
                if new or float(old_price) != float(new_price):
                    new_product.append(info)
            else:
                new_price = float(info[-2].replace('S$',''))
                if new or float(old_price) != float(new_price):
                    new_product.append(info)
                final.append(new_price) # 2nd last value must be a price
            final.append(old_price)
            df.loc[len(df)] = final # append to the end of the dataframe

        
        df['Supplier_Name'] = 'Wine.delivery'
        df['Scraped_Data_Datetime'] = datetime.now()
        #df['Scraped_Data_Old_Price'] = old_price
        df['Product_In_Stock'] = True
        df = df[['Product_Name', 'Supplier_Name', 'Scraped_Data_Datetime', 'Scraped_Data_Old_Price', 'Scraped_Data_New_Price', 'Product_In_Stock']]
        record_scraping('Wine.delivery', datetime.now())
        return post_to_db(df, new_product)

    except NoSuchElementException:
        pass
    return jsonify({
        "code": 500,
        "message": "Product elements not found on the webpage or have not loaded. Check XPATH of products or extend wait time."
    })


def scrape_vivino(winetypes, regions, countries, rating): 
    # takes in: winetypes (list), regions (list), countries (list), rating (str) 
    driver = webdriver.Chrome()
    wait = WebDriverWait(driver, 10)
    url = "https://www.vivino.com/explore"
    driver.maximize_window()
    driver.get(url)
    time.sleep(3)

    # select all price range 
    # # left handle
    slider = driver.find_element(By.XPATH, "//*[@id='explore-page-app']/div/div/div[2]/div[1]/div/div[2]/div[2]/div[2]/div/div[4]")
    move = ActionChains(driver)
    move.click_and_hold(slider).move_by_offset(-100, 0).release().perform()
    # # right handle
    slider = driver.find_element(By.XPATH, "//*[@id='explore-page-app']/div/div/div[2]/div[1]/div/div[2]/div[2]/div[2]/div/div[5]")
    move = ActionChains(driver)
    move.click_and_hold(slider).move_by_offset(200, 0).release().perform()

    try:
        button = driver.find_element(By.XPATH, f"//span[text()='Only show wines with a discount']")
        button.click() # remove: default on the url is to only show discounted
        button = driver.find_element(By.XPATH, "//span[text()='Red']")
        button.click() # remove default red wine selection
    except NoSuchElementException:
        pass

    if rating != '':
        try: # get only items that are rated a certain way
            button = driver.find_element(By.XPATH, f"//div[text()='{rating}']")
            button.click()
        except NoSuchElementException:
            pass
        time.sleep(2)

    if len(winetypes) > 0:
        for cat in winetypes:
            try: 
                button = driver.find_element(By.XPATH, f"//span[text()='{cat}']")
                button.click()
            except NoSuchElementException:
                pass
            time.sleep(2)
    
    if len(regions) > 0:
        for region in regions:
            try: 
                button = driver.find_element(By.XPATH, f"//span[text()='{region}']")
                button.click()
            except NoSuchElementException:
                pass
            time.sleep(2)

    if len(countries) > 0:
        for country in countries:
            try: 
                button = driver.find_element(By.XPATH, f"//span[text()='{country}']")
                button.click()
            except NoSuchElementException:
                pass
            time.sleep(2)
    
    # for infinite scrolling
    last_height = driver.execute_script("return document.body.scrollHeight")
    count = 50 # pre-set number of scrolls to minimise run time
    for i in range(count):
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(3)
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break
        last_height = new_height

    #wait awhile before starting to scrape
    time.sleep(2)
    # scrape data
    wine_names = []
    wine_titles = []
    wine_prices = []
    wine_old_prices = []
    new_product = []
    scraped_wines = get_scraped_data()
    try:
        wines = driver.find_elements(By.XPATH, "//div[@class='wineInfoVintage__vintage--VvWlU wineInfoVintage__truncate--3QAtw']")
        prices = driver.find_elements(By.XPATH, "//div[@class='addToCartButton__price--qJdh4']/div[2]")
        titles = driver.find_elements(By.XPATH, "//div[@class='wineInfoVintage__truncate--3QAtw']")
        for i in range(len(wines)):
            old_price = get_old_price(wines[i].text, scraped_wines)
            wine_old_prices.append(float(old_price))
            new = check_new_updates(wines[i].text,scraped_wines)
            if new or float(old_price) != float(prices[i].text):
                new_product.append([wines[i].text,float(prices[i].text),titles[i].text])
            wine_names.append(wines[i].text)
            wine_prices.append(float(prices[i].text))
            wine_titles.append(titles[i].text)
    except NoSuchElementException:
        print("The elements does not exist / has not loaded yet.")

    df = pd.DataFrame(
        {
            'Product_Name': wine_names,
            'Scraped_Data_New_Price': wine_prices,
            'Scraped_Data_Old_Price' : wine_old_prices
        })
    df['Scraped_Data_Datetime'] = datetime.now()
    df['Supplier_Name'] = 'Vivino'
    df['Product_In_Stock'] = True
    df = df[['Product_Name', 'Supplier_Name', 'Scraped_Data_Datetime', 'Scraped_Data_Old_Price', 'Scraped_Data_New_Price', 'Product_In_Stock']]
    record_scraping('Vivino', datetime.now())
    return post_to_db(df, new_product)


def scrape_pivene():
    driver = webdriver.Chrome()
    wait = WebDriverWait(driver, 10)
    url = "https://www.pivene.com/collections/all"
    driver.maximize_window()
    driver.get(url)
    time.sleep(1)

    try: # get rid of the pop-up
        button = driver.find_element(By.XPATH, "//button[@class='button button-1 mr-10 popup-confirm-yes']")
        button.click()
    except NoSuchElementException:
        pass
    
    
    new_product = []
    #get all scraped wines
    scraped_wines = get_scraped_data()
    i = 1 # page number
    df = pd.DataFrame(columns=['Product_Name', 'Scraped_Data_New_Price', 'Scraped_Data_Old_Price', 'Product_In_Stock'])
    while i <= 80: # 80 pages on the website
        try:
            # pdt_info = driver.find_elements(By.XPATH, "//div[@class='text-left product-each__bottom']")
            normal_wines = driver.find_elements(By.XPATH, "//div[@class='product-each overflow relative form-parent boost-pfs-filter-product-item boost-pfs-filter-product-item-grid boost-pfs-filter-grid-width-3 boost-pfs-filter-grid-width-mb-2 boost-pfs-action-list-enabled']")
            for card in normal_wines:
                wine = card.text.split('\n')
                if wine[0].isnumeric():
                    name = wine[2]
                    temp = [name]
                else:
                    name = wine[1]
                    temp = [name]
                print(wine)
                old_price = get_old_price(name, scraped_wines)
                new = check_new_updates(name,scraped_wines)
                if 'SGD' in wine[2]:
                    price = wine[2].replace(' SGD','').replace(',','')
                    if new or float(old_price) != float(price):
                        new_product.append(wine)
                    temp.append(float(price))
                    temp.append(float(old_price))
                else:
                    price = wine[3].replace(' SGD','').replace(',','')
                    if new or float(old_price) != float(price):
                        new_product.append(wine)
                    temp.append(float(price))
                    temp.append(float(old_price))
                temp.append(True)
                df.loc[len(df)] = temp # append to the end of dataframe
        except NoSuchElementException:
            pass
        try: # for wines on sale (different class name)
            wines_on_sale = driver.find_elements(By.XPATH, "//div[@class='product-each overflow relative form-parent boost-pfs-filter-product-item boost-pfs-filter-product-item-grid boost-pfs-filter-grid-width-3 boost-pfs-filter-grid-width-mb-2 on-sale boost-pfs-action-list-enabled']")
            for card in wines_on_sale:
                wine = card.text.split('\n')
                #website stupid put this wine as sales but turns out just don't have anymore but can't be bothered to change class.
                if wine[0] != 'SALE':
                    if wine[0].isnumeric():
                        name = wine[2]
                        temp = [name]
                    else:
                        name = wine[1]
                        temp = [name]
                    print(wine)
                    old_price = get_old_price(name, scraped_wines)
                    new = check_new_updates(name,scraped_wines)
                    if 'SGD' in wine[2]:
                        price = wine[2].replace(' SGD','').replace(',','')
                        if new or float(old_price) != float(price):
                            new_product.append(wine)
                        temp.append(float(price))
                        temp.append(float(old_price))
                    else:
                        price = wine[3].replace(' SGD','').replace(',','')
                        if new or float(old_price) != float(price):
                            new_product.append(wine)
                        temp.append(float(price))
                        temp.append(float(old_price))
                #actually got sales.
                else:
                    if wine[1].isnumeric():
                        name = wine[3]
                        temp = [name]
                    else:
                        name = wine[2]
                        temp = [name]
                    print(wine)
                    old_price = get_old_price(name, scraped_wines)
                    new = check_new_updates(name,scraped_wines)
                    if 'SGD' in wine[3]:
                        price = wine[3].replace(' SGD','').replace(',','')
                        if new or float(old_price) != float(price):
                            new_product.append(wine)
                        temp.append(float(price))
                        temp.append(float(old_price))
                    else:
                        price = wine[4].replace(' SGD','').replace(',','')
                        if new or float(old_price) != float(price):
                            new_product.append(wine)
                        temp.append(float(price))
                        temp.append(float(old_price))
                temp.append(True)
                df.loc[len(df)] = temp # append to the end of dataframe
        except NoSuchElementException:
            pass
        try: # for wines that are sold out
            wines_no_stock = driver.find_elements(By.XPATH, "//div[@class='product-each overflow relative form-parent boost-pfs-filter-product-item boost-pfs-filter-product-item-grid boost-pfs-filter-grid-width-3 boost-pfs-filter-grid-width-mb-2 sold-out boost-pfs-action-list-enabled']")
            for card in wines_no_stock:
                wine = card.text.split('\n')
                print(wine)
                if wine[0] == 'SOLD OUT':
                    if wine[1].isnumeric():
                        name = wine[3]
                        temp = [name]
                    else:
                        name = wine[2]
                        temp = [name]
                    old_price = get_old_price(name, scraped_wines)
                    new = check_new_updates(name,scraped_wines)
                    if 'SGD' in wine[3]:
                        price = wine[3].replace(' SGD','').replace(',','')
                        if new or float(old_price) != float(price):
                            new_product.append(wine)
                        temp.append(float(price))
                        temp.append(float(old_price))
                    else:
                        price = wine[4].replace(' SGD','').replace(',','')
                        if new or float(old_price) != float(price):
                            new_product.append(wine)
                        temp.append(float(price))
                        temp.append(float(old_price))
                temp.append(False) 
                df.loc[len(df)] = temp # append to the end of dataframe
        except NoSuchElementException:
            pass

        if (i == 1): # to deal with clicking through the pages
            button = driver.find_element(By.XPATH, "/html/body/div[11]/section/div[2]/div[3]/div[1]/div[2]/div[2]/ul/li[7]/a")
            driver.execute_script("arguments[0].click();", button)
            time.sleep(6)
        elif (i == 2 or i == 79):
            button = driver.find_element(By.XPATH, "/html/body/div[11]/section/div[2]/div[3]/div[1]/div[2]/div[2]/ul/li[8]/a")
            driver.execute_script("arguments[0].click();", button)
            time.sleep(6)
        elif (i == 3 or i == 78):
            button = driver.find_element(By.XPATH, "/html/body/div[11]/section/div[2]/div[3]/div[1]/div[2]/div[2]/ul/li[9]/a")
            driver.execute_script("arguments[0].click();", button)
            time.sleep(6)
        elif (i == 4 or i == 77):
            button = driver.find_element(By.XPATH, "/html/body/div[11]/section/div[2]/div[3]/div[1]/div[2]/div[2]/ul/li[10]/a")
            driver.execute_script("arguments[0].click();", button)
            time.sleep(6)
        elif (i>=5 and i<77):
            button = driver.find_element(By.XPATH, "/html/body/div[11]/section/div[2]/div[3]/div[1]/div[2]/div[2]/ul/li[11]/a")
            driver.execute_script("arguments[0].click();", button)
            time.sleep(6)
        i += 1

    df['Supplier_Name'] = 'Pivene'
    df['Scraped_Data_Datetime'] = datetime.now()
    #df['Scraped_Data_Old_Price'] = 0
    df.drop_duplicates(subset='Product_Name', keep='first', inplace=True)
    df = df[['Product_Name', 'Supplier_Name', 'Scraped_Data_Datetime', 'Scraped_Data_Old_Price', 'Scraped_Data_New_Price', 'Product_In_Stock']]
    record_scraping('Pivene', datetime.now())
    return post_to_db(df, new_product)


def scrape_twdc(): # no stock info, no price info
    driver = webdriver.Chrome()
    wait = WebDriverWait(driver, 10)
    url = "https://twdc.com.sg/product-search/"
    driver.maximize_window()
    driver.get(url)
    time.sleep(3)

    i = 1
    new_product = []
    #get all scraped wines
    scraped_wines = get_scraped_data()
    df = pd.DataFrame(columns=['Product_Name'])
    while i <= 12: # 12 pages on the website
        try:
            wines = driver.find_elements(By.XPATH, "//h2[@class='woocommerce-loop-product__title']")
            for card in wines:
                new = check_new_updates(card.text,scraped_wines)
                if new:
                    new_product.append(card.text)
                df.loc[len(df)] = card.text
        except NoSuchElementException:
            pass
        if (i < 13): # toggle to next page
            try:
                button = driver.find_element(By.XPATH, "//a[@class='next page-numbers']")
                driver.execute_script("arguments[0].click();", button)
                time.sleep(5)
            except NoSuchElementException:
                pass
        i += 1

    df['Supplier_Name'] = 'twdc'
    df['Scraped_Data_Datetime'] = datetime.now()
    df['Scraped_Data_Old_Price'] = 0
    df['Scraped_Data_New_Price'] = 0
    df['Product_In_Stock'] = True
    df.drop_duplicates(subset='Product_Name', keep='first', inplace=True)
    df = df[['Product_Name', 'Supplier_Name', 'Scraped_Data_Datetime', 'Scraped_Data_Old_Price', 'Scraped_Data_New_Price', 'Product_In_Stock']]
    record_scraping('twdc', datetime.now())
    return post_to_db(df, new_product)

def scrape_winedelivery():
    driver = webdriver.Chrome()
    wait = WebDriverWait(driver, 10)
    url = "https://winedelivery.sg/product-category/wine/"
    driver.maximize_window()
    driver.get(url)
    time.sleep(3)
    
    try: # clear cookies
        enter_button = driver.find_element(By.XPATH, "//a[@id='cookie_action_close_header']")
        driver.execute_script("arguments[0].click();", enter_button)
    except:
        pass
    
    new_product = []
    #get all scraped wines
    scraped_wines = get_scraped_data()
    i = 1
    df = pd.DataFrame(columns=['Product_Name', 'Scraped_Data_New_Price', 'Scraped_Data_Old_Price'])
    while i <= 57: # 57 pages on the website
        try:
            wines = driver.find_elements(By.XPATH, "//div[@class='product-content']")
            #print("The element exists.")
            for card in wines:
                wine = card.text.split('\n')
                if wine != ['']:
                    temp = [wine[0]] # wine name
                    #print(wine[0])
                    old_price = get_old_price(wine[0], scraped_wines)
                    #print("old price :", old_price)
                    new = check_new_updates(wine[0],scraped_wines)
                    price = wine[1]
                    price = price.replace('$','').replace(',', '').split(' ')
                    if len(price) > 1: # len(list)>1 if there's discount
                        #did not check for price update for winedelivery as they have same 
                        # name but different price without stating the ml difference
                        #Example: BATASIOLO BARBERA D'ALBA DOC SOVRANA 2016
                        if new:
                            new_product.append(wine)
                        temp.append(float(price[1]))
                        temp.append(float(old_price))
                    else:
                        if new:
                            new_product.append(wine)
                        temp.append(float(price[0]))
                        temp.append(float(old_price))
                    df.loc[len(df)] = temp # append to the end of dataframe
        except NoSuchElementException:
            pass
        if (i < 57):
            try:
                button = driver.find_element(By.XPATH, "//a[@class='next page-numbers']")
                driver.execute_script("arguments[0].click();", button)
                time.sleep(5)
            except NoSuchElementException:
                pass
        i += 1
    
    df.drop_duplicates(subset="Product_Name", keep='first', inplace=True)
    df['Supplier_Name'] = 'Winedelivery'
    df['Scraped_Data_Datetime'] = datetime.now()
    #df['Scraped_Data_Old_Price'] = 0
    df['Product_In_Stock'] = True
    df = df[['Product_Name', 'Supplier_Name', 'Scraped_Data_Datetime', 'Scraped_Data_Old_Price', 'Scraped_Data_New_Price', 'Product_In_Stock']]
    record_scraping('Winedelivery', datetime.now())
    return post_to_db(df, new_product)
    

def scrape_winelistasia():
    driver = webdriver.Chrome()
    wait = WebDriverWait(driver, 10)
    url = "https://www.winelistasia.com/online-shop.html"
    driver.maximize_window()
    driver.get(url)
    time.sleep(3)

    i = 1
    df = pd.DataFrame(columns=['Product_Name', 'Scraped_Data_New_Price', 'Product_In_Stock', 'Scraped_Data_Old_Price'])
    scraped_wines = get_scraped_data()
    new_product = []
    while i <= 15: # 15 pages on the website
        try:
            wines = driver.find_elements(By.XPATH, "//div[@class='product-grid__info']")
            for card in wines:
                wine = card.text.split('\n')
                if len(wine) >= 3:
                    if len(wine) > 1:
                        temp = [wine[0]]
                        #get old price
                        old_price = get_old_price(wine[0], scraped_wines)
                        price = wine[1]
                        price = price.replace('SGD ','').replace(',', '').split(' ')
                        new = check_new_updates(wine[0],scraped_wines)
                        if len(price) > 1: # len(list)>1 if there's discount
                            temp.append(float(price[1]))
                            if new or float(old_price) != float(price[1]):
                                #print(float(old_price))
                                #print(float(price[1]))
                                new_product.append(wine)
                        else:
                            temp.append(float(price[0]))
                            if new or float(old_price) != float(price[0]):
                                #print(float(old_price))
                                #print(float(price[0]))
                                new_product.append(wine)
                        if wine[2] == 'Sold out':
                            temp.append(False)
                        else:
                            temp.append(True)
                        
                        temp.append(old_price)
                        df.loc[len(df)] = temp
        except NoSuchElementException:
            pass
        
        try: # toggle pages
            button = driver.find_element(By.XPATH, "//a[@class='product-grid__paging--link product-grid--next js-products-next']")
            driver.execute_script("arguments[0].click();", button)
            time.sleep(10)
        except NoSuchElementException:
            print("The element does not exist / has not loaded yet.")
        i += 1
    
    df.drop_duplicates(subset="Product_Name", keep='first', inplace=True)
    df['Supplier_Name'] = 'Winelistasia'
    df['Scraped_Data_Datetime'] = datetime.now()
    #df['Scraped_Data_Old_Price'] = 0
    df = df[['Product_Name', 'Supplier_Name', 'Scraped_Data_Datetime', 'Scraped_Data_Old_Price', 'Scraped_Data_New_Price', 'Product_In_Stock']]
    
    record_scraping('Winelistasia', datetime.now())
    return post_to_db(df, new_product)
   

def scrape_winesonline():
    driver = webdriver.Chrome()
    wait = WebDriverWait(driver, 10)
    url = "https://winesonline.com.sg/collections/wines"
    driver.maximize_window()
    driver.get(url)
    time.sleep(3)

    i = 1
    df = pd.DataFrame(columns=['Product_In_Stock', 'Product_Name', 'Scraped_Data_New_Price','Scraped_Data_Old_Price'])
    to_remove = ['Sale', 'New', 'Best Buy', 'ADD TO CART', 'NOTIFY ME', ' Sold Out']
    
    new_product = []
    #get all wines
    scraped_wines = get_scraped_data()
    while i <= 29: # 29 pages on the website
        try:
            items = driver.find_elements(By.XPATH, "//div[@class='product-wrap']")
            for item in items:
                cleaned = []
                info = item.text
                info = info.split('\n')
                temp = []
                for x in info:
                    if x not in to_remove:
                        cleaned.append(x)
                    if 'Sold Out' in x:
                        temp.append(False)
                if len(temp) == 0:
                    temp.append(True)
                if '$' in cleaned[1]: # if sold out, may or may not be a price
                    temp.append(cleaned[0])
                    price = cleaned[1]
                    price = price.replace('S$', '').replace(',','').replace(' Sold Out','').replace('Sold Out ','').split(' ')
                    old_price = get_old_price(cleaned[0], scraped_wines)
                    new = check_new_updates(cleaned[0],scraped_wines)
                    if len(price) > 1: # len(list)>1 if there's discount
                        if new or float(old_price) != float(price[1]):
                            new_product.append(cleaned)
                        temp.append(float(price[1]))
                        temp.append(float(old_price))
                    else:
                        if new or float(old_price) != float(price[0]):
                            new_product.append(cleaned)
                        temp.append(float(price[0]))
                        temp.append(float(old_price))
                    df.loc[len(df)] = temp
        except NoSuchElementException:
            pass
        if (i < 29):
            next_page_text = 'https://winesonline.com.sg/collections/wines?page=' + str(i + 1)
            try: 
                button = driver.find_element(By.XPATH, f"//a[@href='{next_page_text}']")
                driver.execute_script("arguments[0].click();", button)
                time.sleep(5)
            except NoSuchElementException:
                pass
        i += 1

    df.drop_duplicates(subset="Product_Name", keep='first', inplace=True)
    df['Supplier_Name'] = 'Winesonline'
    df['Scraped_Data_Datetime'] = datetime.now()
    #df['Scraped_Data_Old_Price'] = 0
    df = df[['Product_Name', 'Supplier_Name', 'Scraped_Data_Datetime', 'Scraped_Data_Old_Price', 'Scraped_Data_New_Price', 'Product_In_Stock']]
    record_scraping('Winesonline', datetime.now())
    return post_to_db(df, new_product)


def scrape_wineswholesale():
    driver = webdriver.Chrome()
    wait = WebDriverWait(driver, 10)
    url = "https://www.wineswholesales.com.sg/collections/all-products?page=1"
    driver.maximize_window()
    driver.get(url)
    time.sleep(3)

    i = 1
    scraped_wines = get_scraped_data()
    new_product = []
    df = pd.DataFrame(columns=['Product_Name', 'Scraped_Data_New_Price', 'Scraped_Data_Old_Price', 'Product_In_Stock'])
    while i <= 76: # 76 pages on the website
        #if there is pop up remove it
        try:
            #<button title="Close (Esc)" type="button" class="mfp-close">×</button>
            button = driver.find_element(By.XPATH, "//button[@class='mfp-close']")
            button.click()
            #print("The element exists.")

        except NoSuchElementException:
            #print("The pop up have not appeared yet.")
            pass
        
        try:
            wines = driver.find_elements(By.XPATH, "//div[@class='right']")
            for wine in wines:
                card = wine.text.split('\n')
                if card != ['']:
                    temp = [card[0]] # product name/title
                    old_price = get_old_price(card[0], scraped_wines)
                    new = check_new_updates(card[0],scraped_wines)
                    if card[1] != "Out of stock":
                        price = card[1]
                        price = price.replace(',','').split('$')
                        if len(price) > 2: # len(list)>2 if there's discount
                            temp.append(float(price[2]))
                            temp.append(float(old_price))
                            if new or float(old_price) != float(price[2]):
                                new_product.append(card)
                        else:
                            temp.append(float(price[1]))
                            temp.append(float(old_price))
                            if new or float(old_price) != float(price[1]):
                                new_product.append(card)

                        temp.append(True)
                    else:
                        temp.append(0)
                        temp.append(0)
                        temp.append(False)
                    df.loc[len(df)] = temp
        except NoSuchElementException:
            pass
        if (i == 1):
            try:
                button = driver.find_element(By.XPATH, "/html/body/div[3]/div[1]/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/div[1]/ul/li[6]/a")
                driver.execute_script("arguments[0].click();", button)
                time.sleep(10)
            except NoSuchElementException:
                pass
        elif (i == 2 or i == 75):
            try:
                button = driver.find_element(By.XPATH, "/html/body/div[3]/div[1]/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/div[1]/ul/li[8]/a")
                driver.execute_script("arguments[0].click();", button)
                time.sleep(10)
            except NoSuchElementException:
                pass
        elif (i == 3 or i == 74):
            try:
                button = driver.find_element(By.XPATH, "/html/body/div[3]/div[1]/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/div[1]/ul/li[9]/a")
                driver.execute_script("arguments[0].click();", button)
                time.sleep(10)
            except NoSuchElementException:
                pass
        elif (i == 4 or i == 73):
            try:
                button = driver.find_element(By.XPATH, "/html/body/div[3]/div[1]/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/div[1]/ul/li[10]/a")
                driver.execute_script("arguments[0].click();", button)
                time.sleep(10)
            except NoSuchElementException:
                pass
        elif (i >= 5 and i < 73):
            try:
                button = driver.find_element(By.XPATH, "/html/body/div[3]/div[1]/div[2]/div[2]/div[2]/div/div/div/div/div[2]/div/div[4]/div[1]/ul/li[11]/a")
                driver.execute_script("arguments[0].click();", button)
                time.sleep(10)
            except NoSuchElementException:
                pass
        i += 1

    df.drop_duplicates(subset="Product_Name", keep='first', inplace=True)
    df['Supplier_Name'] = 'Wineswholesale'
    df['Scraped_Data_Datetime'] = datetime.now()
    #df['Scraped_Data_Old_Price'] = 0
    df = df[['Product_Name', 'Supplier_Name', 'Scraped_Data_Datetime', 'Scraped_Data_Old_Price', 'Scraped_Data_New_Price', 'Product_In_Stock']]
    record_scraping('Wineswholesale', datetime.now())
    return post_to_db(df, new_product)