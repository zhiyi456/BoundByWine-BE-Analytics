from app import app,db
from flask import jsonify
from models.product import *

import pandas as pd
import numpy as np
import shopify
from os import environ
from dotenv import dotenv_values
import json

def refresh_products():
    key = environ.get("SHOPIFY_API_KEY")
    store = environ.get("STORE")
    url = str(store) + ".myshopify.com"
    # access shopify store
    session = shopify.Session(url, '2022-07', key) # 2022-07 is the shopify api version
    shopify.ShopifyResource.activate_session(session)

    resource_type = shopify.Product
    resource_count = resource_type.count()
    #resources = []
    if resource_count > 0:
        page = resource_type.find()
        for pdt in page:
            temp = pdt.to_dict()
            if bool(temp.get('body_html')):
                start = temp['body_html'].find('<p>')
                end = temp['body_html'].find('</p>')
                html = temp['body_html'][start+3:end]
            else: 
                html = ""
            if bool(temp.get('variants')):
                sku = temp['variants'][0]['sku']
                price = float(temp['variants'][0]['price'])
            else: 
                sku = ""
                price = 0
            if bool(temp.get('image')):
                image = temp['image']['src']
            else: 
                image = ""

            to_db = {
                'shopify_product_id': str(temp['id']), 
                'product_name': temp['title'], 
                'product_type': temp['product_type'],
                'product_description': html,
                'image': image,
                'shopify_sku': sku,
                'price': price
            }
            pdt=Product(**to_db)            
            try:
                db.session.add(pdt)
                db.session.commit()
            except:
                return jsonify(
                    {
                        "code": 500,
                        "data": to_db,
                        "message": "An error occurred while creating a particular product."
                    }
                ), 500

        while page.has_next_page():
            page = page.next_page()
            for pdt in page:
                temp = pdt.to_dict()
                if bool(temp.get('body_html')):
                    start = temp['body_html'].find('<p>')
                    end = temp['body_html'].find('</p>')
                    html = temp['body_html'][start+3:end]
                else: 
                    html = ""
                if bool(temp.get('variants')):
                    sku = temp['variants'][0]['sku']
                    price = float(temp['variants'][0]['price'])
                else: 
                    sku = ""
                    price = 0
                if bool(temp.get('image')):
                    image = temp['image']['src']
                else: 
                    image = ""
                to_db = {
                    'shopify_product_id': str(temp['id']), 
                    'product_name': temp['title'], 
                    'product_type': temp['product_type'],
                    'product_description': html,
                    'image': image,
                    'shopify_sku': sku,
                    'price': price
                }
                pdt=Product(**to_db)            
                print(pdt)
                
                try:
                    db.session.add(pdt)
                    db.session.commit()
                except:
                    return jsonify(
                        {
                            "code": 500,
                            "data": to_db,
                            "message": "An error occurred while creating a particular product."
                        }
                    ), 500
    # clear shopify session
    shopify.ShopifyResource.clear_session()
    return jsonify(
        {
            "code": 201,
            "message": "All products from shopify have been successfully created."
        }
    ), 201



def get_shopify_products():
    key = environ.get("SHOPIFY_API_KEY")
    store = environ.get("STORE")
    url = str(store) + ".myshopify.com"
    # access shopify store
    session = shopify.Session(url, '2022-07', key) # 2022-07 is the shopify api version
    shopify.ShopifyResource.activate_session(session)

    resource_type = shopify.Product
    resource_count = resource_type.count()
    resources = {}
    if resource_count > 0:
        page = resource_type.find()
        for pdt in page:
            temp = pdt.to_dict()
            if bool(temp.get('body_html')):
                start = temp['body_html'].find('<p>')
                end = temp['body_html'].find('</p>')
                html = temp['body_html'][start+3:end]
            else: 
                html = np.nan
            if bool(temp.get('variants')):
                sku = temp['variants'][0]['sku']
                price = temp['variants'][0]['price']
            else: 
                sku = np.nan
                price = np.nan
            if bool(temp.get('image')):
                image = temp['image']['src']
            else: 
                image = np.nan
            if pd.isnull(sku) or sku=="": # if no sku, set product title
                resources[temp['title']] = {
                    'id': temp['id'], 
                    'title': temp['title'], 
                    'product_type': temp['product_type'],
                    'cleaned_description': html,
                    'image': image,
                    'sku': sku,
                    'price': price
                }
            else: # sku exists
                resources[sku] = {
                    'id': temp['id'], 
                    'title': temp['title'], 
                    'product_type': temp['product_type'],
                    'cleaned_description': html,
                    'image': image,
                    'sku': sku,
                    'price': price
                }
        while page.has_next_page():
            page = page.next_page()
            for pdt in page:
                temp = pdt.to_dict()
                if bool(temp.get('body_html')):
                    start = temp['body_html'].find('<p>')
                    end = temp['body_html'].find('</p>')
                    html = temp['body_html'][start+3:end]
                else: 
                    html = np.nan
                if bool(temp.get('variants')):
                    sku = temp['variants'][0]['sku']
                    price = temp['variants'][0]['price']
                else: 
                    sku = np.nan
                    price = np.nan
                if bool(temp.get('image')):
                    image = temp['image']['src']
                else: 
                    image = np.nan
                if pd.isnull(sku) or sku=="": # if no sku, set product title
                    resources[temp['title']] = {
                        'id': temp['id'], 
                        'title': temp['title'], 
                        'product_type': temp['product_type'],
                        'cleaned_description': html,
                        'image': image,
                        'sku': sku,
                        'price': price
                    }
                else: # sku exists
                    resources[sku] = {
                        'id': temp['id'], 
                        'title': temp['title'], 
                        'product_type': temp['product_type'],
                        'cleaned_description': html,
                        'image': image,
                        'sku': sku,
                        'price': price
                    }
    # clear shopify session
    shopify.ShopifyResource.clear_session()

    final = json.dumps(resources, indent = 4)
    return jsonify(
        {
            "code": 200,
            "data": resources
        }
    )