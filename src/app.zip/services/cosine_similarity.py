from app import app,db
from flask import jsonify
from services.scraped_data import *

import requests
import json
# Scikit Learn
from sklearn.feature_extraction.text import CountVectorizer
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity


#https://www.machinelearningplus.com/nlp/cosine-similarity/#4howtocomputecosinesimilarityinpython
#https://memgraph.com/blog/cosine-similarity-python-scikit-learn


def compare(name1, name2):
    names = [name1, name2]
    print("compare")
    # Create the Document Term Matrix
    count_vectorizer = CountVectorizer(stop_words='english')
    count_vectorizer = CountVectorizer()
    sparse_matrix = count_vectorizer.fit_transform(names)

    doc_term_matrix = sparse_matrix.todense()
    df = pd.DataFrame(doc_term_matrix, 
                  columns=count_vectorizer.get_feature_names_out(), 
                  index=['name1', 'name2'])

    result = cosine_similarity(df, df)
    #print(compare('Ziereisen Blauer Spatburgunder 2017','Weingut Meyer Nakel Blauschiefer Spatburgunder 2019'))
    return result[0][1]

def calculate_cosine_similarity(bbw_wines_list, suppler_wines_list):
    
    #iterate through bbw wine
    print("calculate cosine similarity")
    
    similar_product = {}
    for bbw_wines in bbw_wines_list:
        if len(similar_product) > 1:
            return similar_product
        similar_product[bbw_wines["product_name"]] = []
        for suppler_wines in suppler_wines_list:
            similarity = compare(bbw_wines["product_name"], suppler_wines['Product_Name'])
            #print(similarity)
            if similarity > 0:
                #add to dict
                #similar_product[bbw_wines["product_name"]] = []
                try:    
                    similar_product[bbw_wines["product_name"]].append(suppler_wines)
                except:
                    print("got error")
    return similar_product





