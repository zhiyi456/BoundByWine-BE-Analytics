from app import client
from flask import jsonify
import models


def get_all_supplier_listing():
    
    if supplier_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "supplier_listing": [supplier.json() for supplier in supplier_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no Suppliers."
        }
    ), 404