from app import client
from flask import jsonify
from models.historical_demand import *

# get_all_historical_demand()
# def get_all_historical():
#     # resp = client.get("products/8596600291647.json?fields=id,title,metafields")
#     resp = client.get("products/8596600291647/metafields.json")
#     print(resp.json())

# def get_all_selected_product_price(product_name):
#     historical_demand_list = HistoricalDemand.query.filter_by(Product_Name = product_name).all()
#     if historical_demand_list:
#         return jsonify(
#             {
#                 "code": 200,
#                 "data": {
#                     "historical_demand": [historical_demand.json() for historical_demand in historical_demand_list]
#                 }
#             }
#         )
#     return jsonify(
#         {
#             "code": 404,
#             "message": 'No historical demand history for product named ' + str(product_name) 
#         }
#     ), 404
