from app import client
from flask import jsonify
from models.scrape_logs import *


def scrape_logs_get_all():
    scrape_logs_list = ScrapeLogs.query.all()
    
    if scrape_logs_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scrape_logs": [scrape_log.json() for scrape_log in scrape_logs_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no scrape log."
        }
    ), 404


def filter_scrape_logs_by_supplier(supplier_name):
    scrape_logs_list = ScrapeLogs.query.filter_by(Supplier_Name = supplier_name).all()
    if scrape_logs_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scrape_log": [scrape_log.json() for scrape_log in scrape_logs_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No scrape logs for ' + str(supplier_name) 
        }
    ), 404
