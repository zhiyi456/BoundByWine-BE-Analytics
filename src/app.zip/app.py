from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import pymysql
from os import environ
from dotenv import load_dotenv
from shopifyapi import ShopifyAPI

app = Flask(__name__)

load_dotenv()

# Remember to add/remove the app config with your php password
app.config['SQLALCHEMY_DATABASE_URI'] = environ.get(
    'dbURL') or 'mysql+mysqlconnector://root:@localhost:3306/grapevantage_rds'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# cara
""" app.config['SQLALCHEMY_DATABASE_URI'] = environ.get(
    'dbURL') or 'mysql+mysqlconnector://root:root@localhost:8889/grapevantage_rds'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False """

app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {'pool_recycle': 299}

db = SQLAlchemy(app)

CORS(app)

client = ShopifyAPI(token=environ.get("SHOPIFY_API_KEY"), store=environ.get("STORE"))

import models.product
import models.supplier
import models.product_listing
import models.historical_demand
import models.predicted_demand
import models.scraped_data
import models.scrape_logs

import services.product
import services.supplier
import services.product_listing
import services.historical_demand
import services.predicted_demand
import services.scraped_data
import services.webscraping
import services.scrape_logs
import services.cosine_similarity

import controllers.product
import controllers.supplier
import controllers.product_listing
import controllers.historical_demand
import controllers.predicted_demand
import controllers.scraped_data
import controllers.test
import controllers.webscraping
import controllers.scrape_logs
import controllers.match_name

if __name__ == '__main__':
    # resp = client.get("products/8596600291647/metafields/count.json?fields=key,value")
    # print(resp.json())
    # with app.app_context():
    #     db.create_all()
    app.run(port=5000, debug=True)