from flask import jsonify
from app import db

class ScrapedData(db.Model):
    __tablename__ = 'Scraped_Data'

    Product_Name = db.Column(db.String(200), primary_key=True)
    Supplier_Name = db.Column(db.String(100), primary_key=True)
    Scraped_Data_Datetime = db.Column(db.DateTime, primary_key=True)
    Scraped_Data_Old_Price = db.Column(db.Float(10,2), nullable=False)
    Scraped_Data_New_Price = db.Column(db.Float(10,2), nullable=False)
    Product_In_Stock = db.Column(db.Boolean, nullable=False)

    def __init__(self, Product_Name, Supplier_Name, Scraped_Data_Datetime, Scraped_Data_Old_Price, Scraped_Data_New_Price, Product_In_Stock):
        self.Product_Name = Product_Name
        self.Supplier_Name = Supplier_Name
        self.Scraped_Data_Datetime = Scraped_Data_Datetime
        self.Scraped_Data_Old_Price = Scraped_Data_Old_Price
        self.Scraped_Data_New_Price = Scraped_Data_New_Price
        self.Product_In_Stock = Product_In_Stock

    def json(self):
        dto = {
            'Product_Name': self.Product_Name,
            'Supplier_Name': self.Supplier_Name,
            'Scraped_Data_Datetime': self.Scraped_Data_Datetime,
            'Scraped_Data_Old_Price': self.Scraped_Data_Old_Price,
            'Scraped_Data_New_Price': self.Scraped_Data_New_Price,
            'Product_In_Stock': self.Product_In_Stock
        }
        return dto 

def scraped_data_get_all():
    scraped_data_list = ScrapedData.query.all()
    
    if scraped_data_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scraped_data": [scraped_data.json() for scraped_data in scraped_data_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no Historical Demand."
        }
    ), 404


def selected_scraped_product_price_get_all(product_name):
    scraped_data_list = ScrapedData.query.filter_by(Product_Name = product_name).all()
    if scraped_data_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scraped_data": [scraped_data.json() for scraped_data in scraped_data_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No historical demand history for product named ' + str(product_name) 
        }
    ), 404
