from flask import jsonify
from app import db

class ProductListing(db.Model):
    __tablename__ = 'Product_Listing'

    Product_Name = db.Column(db.String(200), primary_key=True)
    Supplier_Name = db.Column(db.String(100), primary_key=True)
    Product_Listing_Status = db.Column(db.Boolean, nullable=False)
    Product_Listing_Current_Price = db.Column(db.Float, nullable=False)

    def __init__(self, Product_Name, Supplier_Name, Product_Listing_Status, Product_Listing_Current_Price):
        self.Product_Name = Product_Name
        self.Supplier_Name = Supplier_Name
        self.Product_Listing_Status = Product_Listing_Status
        self.Product_Listing_Current_Price = Product_Listing_Current_Price

    def json(self):
        dto = {
            'Product_Name': self.Product_Name,
            'Supplier_Name': self.Supplier_Name,
            'Product_Listing_Status': self.Product_Listing_Status,
            'Product_Listing_Current_Price': self.Product_Listing_Current_Price
        }
        return dto 


def product_listing_get_all():
    product_listing_list = ProductListing.query.all()
    
    if product_listing_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "product_listing": [product_listing.json() for product_listing in product_listing_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no Historical Demand."
        }
    ), 404


def selected_product_price_get_all(product_name):
    product_listing_list = ProductListing.query.filter_by(Product_Name = product_name).all()
    if product_listing_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "product_listing": [product_listing.json() for product_listing in product_listing_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No historical demand history for product named ' + str(product_name) 
        }
    ), 404
