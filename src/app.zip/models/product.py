from flask import jsonify
from app import db

class Product(db.Model):
    __tablename__ = 'product'

    shopify_product_id = db.Column(db.String(200), primary_key=True)
    product_name = db.Column(db.String(200))
    product_type = db.Column(db.String(200))
    product_description = db.Column(db.String())
    image = db.Column(db.String(200))
    shopify_sku = db.Column(db.String(200))
    price = db.Column(db.Float(5,2))

    def __init__(self, product_name, shopify_product_id, product_type, product_description, image, shopify_sku, price):
        self.product_name = product_name
        self.shopify_product_id = shopify_product_id
        self.product_type = product_type
        self.product_description = product_description
        self.image = image
        self.shopify_sku = shopify_sku
        self.price = price

    def json(self):
        dto = {
            'product_name': self.product_name,
            'shopify_product_id': self.shopify_product_id,
            'product_type': self.product_type,
            'product_description': self.product_description,
            'image': self.image,
            'shopify_sku': self.shopify_sku,
            'price': self.price,
        }
        return dto 


def get_all_product_listing():
    product_list = Product.query.all()
    
    if product_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "product_listing": [product.json() for product in product_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no Historical Demand."
        }
    ), 404