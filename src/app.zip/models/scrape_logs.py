from flask import jsonify
from app import db

class ScrapeLogs(db.Model):
    __tablename__ = 'Scrape_Logs'

    Supplier_Name = db.Column(db.String(100) , primary_key=True)
    Scraped_Data_Datetime = db.Column(db.DateTime, primary_key=True)

    def __init__(self, Supplier_Name, Scraped_Data_Datetime):
        self.Supplier_Name = Supplier_Name
        self.Scraped_Data_Datetime = Scraped_Data_Datetime

    def json(self):
        dto = {
            'Supplier_Name': self.Supplier_Name,
            'Scraped_Data_Datetime': self.Scraped_Data_Datetime
        }
        return dto 


