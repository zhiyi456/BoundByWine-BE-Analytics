from app import app
from flask import jsonify
from services.scrape_logs import *
from sqlalchemy import and_

@app.route("/scrape_logs")
def get_all_scrape_logs():
    return scrape_logs_get_all()
    
    

@app.route("/scrape_logs/<string:supplier_name>", methods=['GET'])
def get_scrape_logs_by_supplier(supplier_name):
    return filter_scrape_logs_by_supplier(supplier_name)