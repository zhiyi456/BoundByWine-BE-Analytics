from app import app
from flask import jsonify

@app.route("/supplier")
def get_all_supplier_listing():
    supplier_list = Supplier.query.all()
    
    if supplier_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "supplier_listing": [supplier.json() for supplier in supplier_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no Suppliers."
        }
    ), 404