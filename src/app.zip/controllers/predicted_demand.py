from app import app
from flask import jsonify
from services.predicted_demand import *

@app.route("/run_predicted_demand_model/<string:product_name>", methods=['GET'])
def run_predicted_demand_model(product_name):
    historical_demand, predicted_demand = run_specific_product_predicted_demand_model(product_name)

    if predicted_demand:
        post_prediction_to_db(predicted_demand)
        return jsonify(
            {
                "code": 200,
                "data": {
                    "historical_demand": historical_demand,
                    "predicted_demand": predicted_demand
                },
                "message": "Predicted demand for this product has also been successfully stored into the database."
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No predicted demand history for product named ' + str(product_name) 
        }
    ), 404

# @app.route("/predicted_demand")
# def get_all_predicted_demand():
#     predicted_demand_list = PredictedDemand.query.all()
    
#     if predicted_demand_list:
#         return jsonify(
#             {
#                 "code": 200,
#                 "data": {
#                     "predicted_demand": [predicted_demand.json() for predicted_demand in predicted_demand_list]
#                 }
#             }
#         )
#     return jsonify(
#         {
#             "code": 404,
#             "message": "There are no Predicted Demand."
#         }
#     ), 404

@app.route("/predicted_demand/<string:product_name>", methods=['GET'])
def get_product_predicted_demand_from_db(product_name):
    return get_product_predicted_demand(product_name)
    # predicted_demand_list =PredictedDemand.query.filter_by(Product_Name = product_name).all()
    # if predicted_demand_list:
    #     return jsonify(
    #         {
    #             "code": 200,
    #             "data": {
    #                 "predicted_demand": [predicted_demand.json() for predicted_demand in predicted_demand_list]
    #             }
    #         }
    #     )
    # return jsonify(
    #     {
    #         "code": 404,
    #         "message": 'No predicted demand history for product named ' + str(product_name) 
    #     }
    # ), 404
