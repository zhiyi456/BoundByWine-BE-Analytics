from app import app
from flask import jsonify
from models.scraped_data import *
from sqlalchemy import and_

@app.route("/scraped_data")
def scraped_data_get_all():
    scraped_data_list = ScrapedData.query.all()
    
    if scraped_data_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scraped_data": [scraped_data.json() for scraped_data in scraped_data_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no scraped data."
        }
    ), 404


@app.route("/scraped_data/<string:product_name>", methods=['GET'])
def selected_scraped_product_price_get_all(product_name):
    scraped_data_list = ScrapedData.query.filter_by(Product_Name = product_name).all()
    if scraped_data_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scraped_data": [scraped_data.json() for scraped_data in scraped_data_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No scraped data for product named ' + str(product_name) 
        }
    ), 404

@app.route("/scraped_data/search/<string:search_query>", methods=['GET'])
def scraped_data_get_specific(search_query):
    search_terms = search_query.split()
    conditions = [ScrapedData.Product_Name.like('%'+term+'%') for term in search_terms]
    results = ScrapedData.query.filter(and_(*conditions)).all()
    if results:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scraped_data": [scraped_data.json() for scraped_data in results]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No scraped data for product named ' + str(search_query) 
        }
    ), 404

#still implementing
@app.route("/scraped_data/get_new_listings")
def get_new_listing():
    scraped_data_list = ScrapedData.query.all()
    
    if scraped_data_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "scraped_data": [scraped_data.json() for scraped_data in scraped_data_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no scraped data."
        }
    ), 404
