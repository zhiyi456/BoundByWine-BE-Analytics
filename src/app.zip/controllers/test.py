from app import app
from flask import jsonify

@app.route("/")
def homepage():
    return "Hello World"