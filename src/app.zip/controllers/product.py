from app import app
from flask import jsonify
from models.product import *
from services.product import *
from sqlalchemy import and_

@app.route("/refresh_products")
def get_all_product_listing():
    result = refresh_products()
    
    # check for errors
    if result is not None:
        return result
    

@app.route('/products', methods=['GET'])
def get_products():
    product_list = Product.query.all()
    if product_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "products_BBW": [product.json() for product in product_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no BBW products."
        }
    ), 404




@app.route("/products/search/<string:search_query>", methods=['GET'])
def get_products_by_name(search_query):
    search_terms = search_query.split()
    conditions = [Product.product_name.like('%'+term+'%') for term in search_terms]
    product_list = Product.query.filter(and_(*conditions)).all()
    if product_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "products_BBW": [product.json() for product in product_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no BBW products."
        }
    ), 404