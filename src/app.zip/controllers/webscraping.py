from app import app
from flask import jsonify, request
from models.scraped_data import *
from services.webscraping import *

@app.route('/scrape_wine_delivery/<category>/<country>')
def scrape_wine_delivery_to_db(category, country):
    result = scrape_wine_delivery(category, country)
    
    # check for errors
    if result is not None:
        return result
    
    # sample query
    # /scrape_wine_delivery/Spirit/Germany

@app.route('/scrape_vivino', methods=['POST'])
def scrape_vivino_to_db():
    data = request.get_json()
    # key-value: winetypes (list), regions (list), countries (list), rating (str)
    result = scrape_vivino(data["winetypes"], data["regions"], data["countries"], data["rating"])
    
    # check for errors
    if result is not None:
        return result
    
    # sample json to test - this will scrape 5 wines only:
    """ {
        "winetypes": ["Rosé", "Sparkling"],
        "regions": [],
        "countries": ["Chile", "Argentina", "Australia"],
        "rating": "Very rare stuff"
    } """

@app.route('/scrape_pivene')
def scrape_pivene_to_db():
    result = scrape_pivene()
    
    # check for errors
    if result is not None:
        return result

@app.route('/scrape_twdc')
def scrape_twdc_to_db():
    result = scrape_twdc()
    
    # check for errors
    if result is not None:
        return result

@app.route('/scrape_winedelivery')
def scrape_winedelivery_to_db():
    result = scrape_winedelivery()
    
    # check for errors
    if result is not None:
        return result

@app.route('/scrape_winelistasia')
def scrape_winelistasia_to_db():
    result = scrape_winelistasia()
    
    # check for errors
    if result is not None:
        return result

@app.route('/scrape_winesonline')
def scrape_winesonline_to_db():
    result = scrape_winesonline()
    
    # check for errors
    if result is not None:
        return result

@app.route('/scrape_wineswholesale')
def scrape_wineswholesale_to_db():
    result = scrape_wineswholesale()
    
    # check for errors
    if result is not None:
        return result