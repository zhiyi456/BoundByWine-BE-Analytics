from app import app
from flask import jsonify

@app.route("/product_listing")
def product_listing_get_all():
    product_listing_list = ProductListing.query.all()
    
    if product_listing_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "product_listing": [product_listing.json() for product_listing in product_listing_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no Historical Demand."
        }
    ), 404


@app.route("/product_listing/<string:product_name>", methods=['GET'])
def selected_product_price_get_all(product_name):
    product_listing_list = ProductListing.query.filter_by(Product_Name = product_name).all()
    if product_listing_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "product_listing": [product_listing.json() for product_listing in product_listing_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No historical demand history for product named ' + str(product_name) 
        }
    ), 404
