from app import app
from flask import jsonify, request
import requests

from services.cosine_similarity import *

from services.scraped_data import *
from models.scraped_data import *


@app.route('/match_name')
def match_wines():
    #get all scraped data wine & get all bbw product
    dict_matched = {}
    try:
        #get supplier wine
        scraped_data = requests.get('http://127.0.0.1:5000/scraped_data')
        response_data = scraped_data.json()
        # Access all the wines scraped (all details)
        
        supplier_wine_names = response_data["data"]["scraped_data"]
        

        # #get bbw wine
        bbw_wine = requests.get('http://127.0.0.1:5000/products')
        response_data1 = bbw_wine.json()

        #Access the "Product_Name" from the first item in the "scraped_data" list
        bbw_wine_names = response_data1["data"]["products_BBW"]

        #O(n^2) good luck
        dict_matched = calculate_cosine_similarity(bbw_wine_names, supplier_wine_names)
        #print(s_wine_names)
    except:
        print("Error retrieving wine data from scraped data or products.")
    
    return dict_matched
