from app import app
from flask import jsonify

@app.route("/historical_demand")
def get_all_historical_demand():
    historical_demand_list = HistoricalDemand.query.all()
    
    if historical_demand_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "historical_demand": [historical_demand.json() for historical_demand in historical_demand_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": "There are no Historical Demand."
        }
    ), 404


@app.route("/historical_demand/<string:product_name>", methods=['GET'])
def get_all_selected_product_price(product_name):
    historical_demand_list = HistoricalDemand.query.filter_by(Product_Name = product_name).all()
    if historical_demand_list:
        return jsonify(
            {
                "code": 200,
                "data": {
                    "historical_demand": [historical_demand.json() for historical_demand in historical_demand_list]
                }
            }
        )
    return jsonify(
        {
            "code": 404,
            "message": 'No historical demand history for product named ' + str(product_name) 
        }
    ), 404
